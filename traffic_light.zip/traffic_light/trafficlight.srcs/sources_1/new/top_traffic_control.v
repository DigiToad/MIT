`timescale 1ns / 1ps

module top_traffic_control(
input clk,
input rst,
output [2:0] n_lights,s_lights,e_lights,w_lights
    );
    wire slow_clk;
     clock_divider #(100_000_000) clkdiv (
        .clk(clk),
        .rst(rst),
        .slow_clk(slow_clk)
    );
    
    traffic_control uut(slow_clk,rst,n_lights,s_lights,e_lights,w_lights);
    
endmodule

module clock_divider #(parameter DIVISOR=100_000_000)(
input clk,
input rst,
output reg slow_clk
);

reg [31:0] counter=0;

always @(posedge clk or posedge rst) begin
if(rst) begin
counter<=0;
slow_clk<=0;
end
else begin
if(counter==(DIVISOR/2-1)) begin
counter<=0;
slow_clk<=~slow_clk;
end
else
counter<=counter+1;
end
end
endmodule